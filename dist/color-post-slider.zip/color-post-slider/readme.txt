=== Post Title Color ===
Contributors: trepmal
Tags: post, title, colorpicker
Donate link: http://kaileylampert.com/donate/
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 1.3

Puts a colorpicker on the edit posts pages so you can change the color of the title in your blog

== Description ==
Puts a colorpicker on the edit posts pages so you can change the color of the title in your blog

I'm on [Twitter](http://twitter.com/trepmal/)

== Installation ==

= Installation =
1. Download the zip file and upload the contents to your plugins directory (defaul `wp-content/plugins`)
2. Activate the plugin through the 'plugins' page in WP.
3. Edit a post and find the colorpicker in the side (for 2-colomn layouts)

== Screenshots ==

1. The colorpicker (pre plugin version 1.2)

== Other Notes ==

This can be enabled for pages by simply uncommnenting lines 45, 65-67

== Upgrade Notice ==
= 1.3 =
Fixes javascript error. Sorry guys!

= 1.2 =
Requires WordPress 3.5

== Changelog ==

= Version 1.3 =
* Oops, Javascript error. Now it works. Sorry guys!

= Version 1.2 =
* Uses new WordPress 3.5 colorpicker.  

= Version 1.1 =
* Keep the post title changes in the main post loop. Sidebar/secondary loops should maintain default title colors.
* Code improvements
* Fix plugin homepage link

= Version 1.0 =
* Initial release version.
